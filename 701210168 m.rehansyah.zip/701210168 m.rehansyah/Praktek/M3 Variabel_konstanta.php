<?php

define('HALO', 'Hello World!');
define('PI', '3.14');

echo HALO;
echo "</br>";
echo PI;

?>
