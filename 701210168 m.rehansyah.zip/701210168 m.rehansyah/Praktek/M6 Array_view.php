<?php
$bulan = array("Januari", "Februari", "Maret", "April", "Mei");
$angka = [1,2,3,4,5];

echo "Ini isi array bulan : </br>";
var_dump($bulan);
echo "</br>";

echo "Ini isi array angka : </br>";
print_r($angka);
echo "</br>";

echo "Ini isi index ke 2 dari array bulan : </br>";
echo $bulan[2];
echo "</br>";

?>