<?php

$angka = 10;
echo "Aku adalah angka $angka.</br>";
$hasilkali = $angka * 8;
echo "jika aku di kali 8, jumlahku sekarang $hasilkali. </br>";

$angka = 80;
$hasilbagi = $angka / 4;
echo "jika aku di bagi 4, jumlahku sekarang $hasilbagi. </br>";

$angka = 20;
$hasilkurang = $angka - 6;
echo "jika aku di kurang 6, jumlahku sekarang $hasilkurang. </br>";

$angka = 14;
$hasiltambah = $angka + 2;
echo "jika aku di tambah 2, jumlahku sekarang $hasiltambah. </br>";

?>