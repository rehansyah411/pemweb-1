<?php

$a = "hello";
$hello = "Hello World!";

echo $a . "</br>";
echo $hello . "</br>";
echo $$a . "</br>";

?>