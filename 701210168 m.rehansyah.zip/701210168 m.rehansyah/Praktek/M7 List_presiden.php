<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>List Nama Presiden RI</title>
</head>
<body>
    <ul>
        <li><a href = "M7 Salam.php?nama=Ir.Soekarno">Ir.Soekarno</a></li>
        <li><a href = "M7 Salam.php?nama=Soeharto">Soeharto</a></li>
        <li><a href = "M7 Salam.php?nama=B.J Habibie">B.J Habibie</a></li>
        <li><a href = "M7 Salam.php?nama=Abdurahman Wahid">Abdurahman Wahido</a></li>
    </ul>
</body>
</html>
