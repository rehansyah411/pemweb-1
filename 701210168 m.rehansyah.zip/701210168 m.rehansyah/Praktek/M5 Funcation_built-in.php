<?php
echo strlen ("M.REHANSYAH");
echo "</br>";
echo date ("d - M - Y");
echo "</br>";
echo htmlspecialchars("<img src='img.jpg'>", ENT_NOQUOTES);
?>