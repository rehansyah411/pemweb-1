<?php

$nrp = "701210168";
$nama = "M.REHANSYAH";
$umur = 22;
$nilai = 95.95;

echo "Nrp : " . $nrp . "</br>";
echo "Nama : " . $nama . "</br>";
print "Umur : " . $umur . "</br>";
printf ("Nilai : %.3f</br>", $nilai);

?>