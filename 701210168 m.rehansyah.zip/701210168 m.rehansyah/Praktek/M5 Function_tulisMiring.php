<?php

function tulis_miring($text) {
    echo "<i>$text</i>";
}

echo tulis_miring("Saya M.REHANSYAH!");

?>