<!DOCTYPE html>
<html>
<head>
    <title>lagu balon</title>
</head>
<body>

<?php

$warna = ["hijau", "kuning", "kelabu", "merah muda", "biru"];

echo "Balonku ada lima.<br>";
echo "Rupa-rupa warna-nya<br>";
echo "$warna[0], $warna[1], $warna[2], $warna[3], dan $warna[4]<br>";
echo "Meletus balon $warna[0] DOR!!!<br>";
echo "Hatiku sangat kacau.";
?>

</body>
</html>